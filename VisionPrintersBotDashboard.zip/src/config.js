export const TELEGRAM_ID = '6978262956';
export const TELEGRAM_USERNAME = '@binarytraderkenya';