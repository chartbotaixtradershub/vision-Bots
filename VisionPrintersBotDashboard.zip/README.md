# VisionPrinters Bot Dashboard
A rebranded automated trading dashboard.